<?php

namespace HubletoApp\External\MyApp;

class Loader extends \HubletoMain\Core\App
{

  public function init(): void
  {
    parent::init();

    $this->main->router->httpGet([
      '/^my-app\/?$/' => Controllers\Dashboard::class,
      '/^my-app\/contacts\/?$/' => Controllers\Contacts::class,
    ]);

    $this->main->sidebar->addLink(
      1, // sidebar level to add link to
      1000, // link ordering index
      'my-app', // URL to navigate to
      $this->translate('My App'), // title
      'fas fa-star', // icon
      str_starts_with($this->main->requestedUri, 'my-app') // is highlighted
    );
  }

  public function installTables()
  {
    $mContact = new \HubletoApp\External\MyApp\Models\Contact($this->main);
    $mContact->dropTableIfExists()->install();
  }
}
