<?php
namespace HubletoApp\MyApp;
class Loader extends \HubletoMain\Core\App {
  public function init(): void {
    $this->app->router->httpGet([ '/^my-app\/?$/' => Controllers\Dashboard::class ]);
    $this->app->sidebar->addLink(
      1,
      1000,
      'help',
      $this->translate('My App'),
      'fas fa-star',
      str_starts_with($this->app->requestedUri, 'my-app')
    );
  }
}
