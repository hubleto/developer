<?php
namespace HubletoApp\MyApp;
class Loader extends \HubletoMain\Core\App {
  public function init(): void {
    $this->app->router->httpGet([ '/^my-app\/?$/' => Controllers\Dashboard::class ]);
    $this->app->router->httpGet([ '/^my-app\/contacts\/?$/' => Controllers\Contacts::class ]);
    $this->app->sidebar->addLink(
      1, // sidebar level to add link to
      1000, // link ordering index
      'my-app', // URL to navigate to
      $this->translate('My App'), // title
      'fas fa-star', // icon
      str_starts_with($this->app->requestedUri, 'my-app') // is highlighted
    );
  }
  public function installTables() {
    $mContact = new \HubletoApp\MyApp\Models\Contact($this->app);
    $mContact->dropTableIfExists()->install();
  }
}
