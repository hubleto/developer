<?php

namespace HubletoApp\External\MyCompany\MyApp\Controllers;

class Contacts extends \HubletoMain\Core\Controller
{

  public function prepareView(): void
  {
    parent::prepareView();
    $this->setView('@HubletoApp:External:MyCompany:MyApp/Contacts.twig');
  }

}