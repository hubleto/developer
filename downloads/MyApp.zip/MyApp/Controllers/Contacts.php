<?php

namespace HubletoApp\External\MyApp\Controllers;

class Contacts extends \HubletoMain\Core\Controller
{

  public function prepareView(): void
  {
    parent::prepareView();
    $this->setView('@app/External/MyApp/Views/Contacts.twig');
  }

}