<?php
namespace HubletoApp\MyApp\Controllers;
class Contacts extends \HubletoMain\Core\Controller {
  public function prepareView(): void {
    parent::prepareView();
    $this->setView('@app/MyApp/Views/Contacts.twig');
  }
}