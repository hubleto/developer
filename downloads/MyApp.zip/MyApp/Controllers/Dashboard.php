<?php
namespace HubletoApp\External\MyApp\Controllers;
class Dashboard extends \HubletoMain\Core\Controller {
  public function prepareView(): void {
    parent::prepareView();
    $this->viewParams['now'] = date('Y-m-d H:i:s');
    $this->setView('@app/External/MyApp/Views/Dashboard.twig');
  }
}
