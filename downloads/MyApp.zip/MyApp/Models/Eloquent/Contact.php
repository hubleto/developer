<?php
namespace HubletoApp\MyAppWithModels\Models\Eloquent;
class Contact extends \ADIOS\Core\Model\Eloquent {
  public $table = 'contacts';
}
