<?php
namespace HubletoApp\MyApp\Models\Eloquent;
class Contact extends \ADIOS\Core\Model\Eloquent {
  public $table = 'my_app_contacts';
}
