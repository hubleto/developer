<?php

namespace HubletoApp\External\MyCompany\MyApp\Models\Eloquent;

use \Illuminate\Database\Eloquent\Relations\BelongsTo;
use \HubletoApp\Community\Settings\Models\Eloquent\User;

class Contact extends \ADIOS\Core\Model\Eloquent
{

  public $table = 'my_app_contacts';

  public function OWNER(): BelongsTo {
    return $this->belongsTo(User::class, 'id_user', 'id');
  }

}
