<?php

namespace HubletoApp\External\MyApp\Models;

use \HubletoApp\Community\Settings\Models\User;

class Contact extends \HubletoMain\Core\Model
{

  public string $table = 'my_app_contacts';
  public string $eloquentClass = Eloquent\Contact::class;

  public array $relations = [ 
    'OWNER' => [ self::BELONGS_TO, User::class, 'id_owner', 'id' ]
  ];

  public function columns(array $columns = []): array
  {
    return parent::columns(array_merge($columns, [
      'first_name' => [
        'type' => 'varchar',
        'title' => $this->translate('First name'),
        'required' => true,
      ],
      'last_name' => [
        'type' => 'varchar',
        'title' => $this->translate('Last name'),
        'required' => true,
      ],
      'id_owner' => [
        'type' => 'lookup',
        'title' => $this->translate('Owner'),
        'model' => User::class,
      ],
    ]));
  }

}
