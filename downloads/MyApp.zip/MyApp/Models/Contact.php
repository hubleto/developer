<?php
namespace HubletoApp\MyAppWithModels\Models;
class Contact extends \HubletoMain\Core\Model {
  public string $table = 'contacts';
  public string $eloquentClass = Eloquent\Contact::class;
  public function columns(array $columns = []): array {
    return parent::columns(array_merge($columns, [
      'first_name' => [
        'type' => 'varchar',
        'title' => $this->translate('Type'),
        'required' => true,
      ],
      'last_name' => [
        'type' => 'varchar',
        'title' => $this->translate('Type'),
        'required' => true,
      ],
    ]));
  }
}
