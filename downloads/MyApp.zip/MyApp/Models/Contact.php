<?php

namespace HubletoApp\External\MyApp\Models;

use \HubletoApp\Community\Settings\Models\User;

class Contact extends \HubletoMain\Core\Model
{

  public string $table = 'my_app_contacts';
  public string $eloquentClass = Eloquent\Contact::class;

  public array $relations = [ 
    'OWNER' => [ self::BELONGS_TO, User::class, 'id_owner', 'id' ]
  ];

  public function columns(array $columns = []): array
  {
    return parent::columns(array_merge($columns, [
      'first_name' => (new \ADIOS\Core\Db\Column\Varchar($this, $this->translate('First name')))->setRequired(),
      'last_name' => (new \ADIOS\Core\Db\Column\Varchar($this, $this->translate('Last name')))->setRequired(),
      'id_owner' => (new \ADIOS\Core\Db\Column\Lookup($this, $this->translate('Owner'), User::class)),
    ]));
  }

}
